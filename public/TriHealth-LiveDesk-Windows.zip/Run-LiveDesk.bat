@echo off
cd /d "%~dp0"
REM Prefer compiled host (port 47811). Fallbacks: PowerShell, then zero-server HTML.
if exist "%~dp0TriHealth-LiveDesk.exe" (
  start "" "%~dp0TriHealth-LiveDesk.exe"
  exit /b 0
)
if exist "%~dp0TriHealth-LiveDesk.ps1" (
  powershell -NoProfile -ExecutionPolicy Bypass -WindowStyle Normal -File "%~dp0TriHealth-LiveDesk.ps1"
  exit /b 0
)
if exist "%~dp0LiveDesk.hta" (
  start "" "%~dp0LiveDesk.hta"
  exit /b 0
)
start "" "%~dp0LiveDesk.html"
