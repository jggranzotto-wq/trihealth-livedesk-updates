# Tri-Health Wellness Centre — Live Desk (PowerShell WinForms)
# Read-only. No API keys. No trading. Double-click Run-LiveDesk.bat to launch.
#Requires -Version 5.1
Set-StrictMode -Version Latest
$ErrorActionPreference = 'Stop'
Add-Type -AssemblyName System.Windows.Forms
Add-Type -AssemblyName System.Drawing
[System.Windows.Forms.Application]::EnableVisualStyles()

$ScriptDir = Split-Path -Parent $MyInvocation.MyCommand.Path
$ConfigPath = Join-Path $ScriptDir 'positions.json'

function Get-DefaultConfig {
  return @{
    usd_cad_fallback = 1.3989
    btc_cad_stop = 113000
    poll_ms = 4000
    positions = @(
      @{ symbol='RAY'; binance='RAYUSDT'; qty=32.437; entry=1.6507; stop=1.5586 }
      @{ symbol='BONK'; binance='BONKUSDT'; qty=16924950; entry=0.0000028788; stop=0.000002706 }
      @{ symbol='PYTH'; binance='PYTHUSDT'; qty=690.53; entry=0.06482; stop=0.06093 }
      @{ symbol='JUP'; binance='JUPUSDT'; qty=172.931; entry=0.258843; stop=0.24333 }
    )
    watch = @(
      @{ symbol='BTC'; binance='BTCUSDT' }
      @{ symbol='ETH'; binance='ETHUSDT' }
      @{ symbol='SOL'; binance='SOLUSDT' }
      @{ symbol='PEPE'; binance='PEPEUSDT' }
      @{ symbol='DOGE'; binance='DOGEUSDT' }
    )
    grids = @{
      DOGE = @{ range_low=0.075; range_high=0.084; stop=0.072 }
      PEPE = @{ range_low=0.0000044; range_high=0.0000051; stop=0.0000042 }
    }
  }
}

function Read-Config {
  if (-not (Test-Path $ConfigPath)) {
    $cfg = Get-DefaultConfig
    ($cfg | ConvertTo-Json -Depth 6) | Set-Content -Path $ConfigPath -Encoding UTF8
    return $cfg
  }
  try {
    return Get-Content -Raw -Path $ConfigPath | ConvertFrom-Json
  } catch {
    return Get-DefaultConfig
  }
}

function Format-Price([double]$n) {
  if ($n -ge 1000) { return $n.ToString('N2') }
  if ($n -ge 1) { return $n.ToString('0.0000') }
  if ($n -ge 0.01) { return $n.ToString('0.00000') }
  if ($n -ge 0.0001) { return $n.ToString('0.0000000') }
  return $n.ToString('0.0000E+0')
}

function Get-Json($url) {
  return Invoke-RestMethod -Uri $url -TimeoutSec 8 -Headers @{ 'User-Agent' = 'TriHealth-LiveDesk-PS/1.0' }
}

function Get-Prices($symbols) {
  $map = @{}
  try {
    foreach ($s in $symbols) {
      $j = Get-Json "https://api.binance.com/api/v3/ticker/24hr?symbol=$s"
      $map[$s] = @{ last = [double]$j.lastPrice; chg = [double]$j.priceChangePercent }
    }
    return @{ source = 'Binance'; map = $map }
  } catch {
    try {
      foreach ($s in $symbols) {
        $j = Get-Json "https://api.binance.com/api/v3/ticker/price?symbol=$s"
        $map[$s] = @{ last = [double]$j.price; chg = 0.0 }
      }
      return @{ source = 'Binance/price'; map = $map }
    } catch {
      $j = Get-Json 'https://api.crypto.com/exchange/v1/public/get-tickers'
      $data = @()
      if ($j.result -and $j.result.data) { $data = $j.result.data }
      $cc = @{}
      foreach ($row in $data) {
        $name = $row.i; if (-not $name) { $name = $row.instrument_name }
        $px = $row.a; if (-not $px) { $px = $row.k }; if (-not $px) { $px = $row.last }
        if ($name -and $px) { $cc[$name] = [double]$px }
      }
      foreach ($s in $symbols) {
        $k = ($s -replace 'USDT$','_USDT') -replace 'USD$','_USD'
        $px = $null
        if ($cc.ContainsKey($k)) { $px = $cc[$k] }
        elseif ($cc.ContainsKey(($k -replace '_USDT$','_USD'))) { $px = $cc[($k -replace '_USDT$','_USD')] }
        if ($null -eq $px) { throw "missing $s on Crypto.com" }
        $map[$s] = @{ last = $px; chg = 0.0 }
      }
      return @{ source = 'Crypto.com'; map = $map }
    }
  }
}

$script:UsdCad = 1.3989
$script:Source = '…'

$form = New-Object System.Windows.Forms.Form
$form.Text = 'Tri-Health desk — live'
$form.Size = New-Object System.Drawing.Size(1100, 720)
$form.StartPosition = 'CenterScreen'
$form.BackColor = [System.Drawing.Color]::FromArgb(11,15,20)
$form.ForeColor = [System.Drawing.Color]::FromArgb(232,238,246)
$form.Font = New-Object System.Drawing.Font('Segoe UI', 9)

$hdr = New-Object System.Windows.Forms.Label
$hdr.Text = 'Tri-Health desk — live  ·  read-only  ·  edit positions.json beside this script'
$hdr.AutoSize = $false
$hdr.Dock = 'Top'
$hdr.Height = 36
$hdr.Padding = New-Object System.Windows.Forms.Padding(12,10,12,0)
$hdr.Font = New-Object System.Drawing.Font('Segoe UI', 11, [System.Drawing.FontStyle]::Bold)
$form.Controls.Add($hdr)

$metrics = New-Object System.Windows.Forms.Label
$metrics.Dock = 'Top'
$metrics.Height = 70
$metrics.Padding = New-Object System.Windows.Forms.Padding(12,4,12,4)
$metrics.Font = New-Object System.Drawing.Font('Consolas', 10)
$form.Controls.Add($metrics)

$grid = New-Object System.Windows.Forms.DataGridView
$grid.Dock = 'Fill'
$grid.BackgroundColor = [System.Drawing.Color]::FromArgb(18,24,33)
$grid.ForeColor = [System.Drawing.Color]::FromArgb(232,238,246)
$grid.GridColor = [System.Drawing.Color]::FromArgb(30,42,56)
$grid.BorderStyle = 'None'
$grid.RowHeadersVisible = $false
$grid.AllowUserToAddRows = $false
$grid.AllowUserToDeleteRows = $false
$grid.ReadOnly = $true
$grid.SelectionMode = 'FullRowSelect'
$grid.AutoSizeColumnsMode = 'Fill'
$grid.ColumnHeadersDefaultCellStyle.BackColor = [System.Drawing.Color]::FromArgb(14,20,28)
$grid.ColumnHeadersDefaultCellStyle.ForeColor = [System.Drawing.Color]::FromArgb(139,155,176)
$grid.DefaultCellStyle.BackColor = [System.Drawing.Color]::FromArgb(18,24,33)
$grid.DefaultCellStyle.ForeColor = [System.Drawing.Color]::FromArgb(232,238,246)
$grid.DefaultCellStyle.SelectionBackColor = [System.Drawing.Color]::FromArgb(40,60,80)
$grid.EnableHeadersVisualStyles = $false
foreach ($c in @('Symbol','Qty','Entry','Price','Value','P&L $','P&L %','Stop','To stop')) {
  [void]$grid.Columns.Add($c, $c)
}
$form.Controls.Add($grid)
$grid.BringToFront()

$notes = New-Object System.Windows.Forms.Label
$notes.Dock = 'Bottom'
$notes.Height = 110
$notes.Padding = New-Object System.Windows.Forms.Padding(12,8,12,8)
$notes.Font = New-Object System.Drawing.Font('Segoe UI', 9)
$form.Controls.Add($notes)

$status = New-Object System.Windows.Forms.Label
$status.Dock = 'Bottom'
$status.Height = 28
$status.Padding = New-Object System.Windows.Forms.Padding(12,4,12,4)
$status.ForeColor = [System.Drawing.Color]::FromArgb(139,155,176)
$form.Controls.Add($status)

$timer = New-Object System.Windows.Forms.Timer
$timer.Interval = 4000

function Update-Board {
  try {
    $cfg = Read-Config
    if ($cfg.poll_ms) { $timer.Interval = [int]$cfg.poll_ms }
    if ($cfg.usd_cad_fallback) { $script:UsdCad = [double]$cfg.usd_cad_fallback }
    try {
      $fx = Get-Json 'https://open.er-api.com/v6/latest/USD'
      if ($fx.rates.CAD) { $script:UsdCad = [double]$fx.rates.CAD }
    } catch {}

    $syms = New-Object System.Collections.Generic.List[string]
    foreach ($p in $cfg.positions) {
      $b = $p.binance; if (-not $b) { $b = "$($p.symbol)USDT" }
      if (-not $syms.Contains($b)) { $syms.Add($b) }
    }
    foreach ($w in $cfg.watch) {
      $b = $w.binance; if (-not $b) { $b = "$($w.symbol)USDT" }
      if (-not $syms.Contains($b)) { $syms.Add($b) }
    }
    $prices = Get-Prices $syms
    $map = $prices.map
    $script:Source = $prices.source

    $grid.Rows.Clear()
    $totalPnl = 0.0; $totalVal = 0.0; $totalCost = 0.0; $near = 0; $atStopN = 0
    foreach ($p in $cfg.positions) {
      $b = $p.binance; if (-not $b) { $b = "$($p.symbol)USDT" }
      if (-not $map.ContainsKey($b)) { continue }
      $price = [double]$map[$b].last
      $qty = [double]$p.qty; $entry = [double]$p.entry; $stop = [double]$p.stop
      $value = $qty * $price; $cost = $qty * $entry; $pnl = $value - $cost
      $pnlPct = if ($cost -ne 0) { ($pnl / $cost) * 100 } else { 0 }
      $dist = if ($price -ne 0) { (($price - $stop) / $price) * 100 } else { 0 }
      $atStop = $price -le $stop
      $nearStop = $dist -le 2
      $totalPnl += $pnl; $totalVal += $value; $totalCost += $cost
      if ($nearStop) { $near++ }
      if ($atStop) { $atStopN++ }
      $idx = $grid.Rows.Add(
        $p.symbol,
        $qty.ToString('N0'),
        (Format-Price $entry),
        (Format-Price $price),
        ('{0:C2}' -f $value),
        ('{0:C2}' -f $pnl),
        ('{0:+0.00;-0.00;0}%' -f $pnlPct),
        (Format-Price $stop),
        ('{0:0.00}%' -f $dist)
      )
      if ($atStop -or $nearStop) {
        $grid.Rows[$idx].DefaultCellStyle.BackColor = [System.Drawing.Color]::FromArgb(60, 20, 24)
        $grid.Rows[$idx].DefaultCellStyle.ForeColor = [System.Drawing.Color]::FromArgb(255, 180, 180)
      }
    }

    $btc = 0.0; $btcChg = 0.0
    if ($map.ContainsKey('BTCUSDT')) { $btc = [double]$map['BTCUSDT'].last; $btcChg = [double]$map['BTCUSDT'].chg }
    $btcCad = [math]::Round($btc * $script:UsdCad)
    $btcStop = 113000
    if ($cfg.btc_cad_stop) { $btcStop = [double]$cfg.btc_cad_stop }
    $deskPct = if ($totalCost -ne 0) { ($totalPnl / $totalCost) * 100 } else { 0 }
    $metrics.Text = ("Desk P&L {0:C2} ({1:+0.00;-0.00}%)   |   Mark {2:C2}   |   Near/at stop {3}/{4}   |   BTC CAD ${5:N0} (USD {6} × {7:N4})" -f `
      $totalPnl, $deskPct, $totalVal, $near, $atStopN, $btcCad, (Format-Price $btc), $script:UsdCad)

    $doge = $null; $pepe = $null
    if ($map.ContainsKey('DOGEUSDT')) { $doge = [double]$map['DOGEUSDT'].last }
    if ($map.ContainsKey('PEPEUSDT')) { $pepe = [double]$map['PEPEUSDT'].last }
    $dg = $cfg.grids.DOGE; $pg = $cfg.grids.PEPE
    $lines = @()
    $lines += ("BTC vs Wealthsimple stop — CAD ${0:N0} · stop ${1:N0} CAD · {2}" -f $btcCad, $btcStop, $(if ($btcCad -le $btcStop) { 'BELOW STOP — check if filled' } else { 'above stop' }))
    if ($null -ne $doge -and $dg) {
      $lines += ("DOGE grid — range {0}–{1} · stop {2} · spot {3} · {4:0.00}% above stop" -f (Format-Price ([double]$dg.range_low)), (Format-Price ([double]$dg.range_high)), (Format-Price ([double]$dg.stop)), (Format-Price $doge), ((($doge - [double]$dg.stop) / $doge) * 100))
    }
    if ($null -ne $pepe -and $pg) {
      $lines += ("PEPE grid — range {0}–{1} · stop {2} · spot {3} · {4:0.00}% above stop" -f (Format-Price ([double]$pg.range_low)), (Format-Price ([double]$pg.range_high)), (Format-Price ([double]$pg.stop)), (Format-Price $pepe), ((($pepe - [double]$pg.stop) / $pepe) * 100))
    }
    $notes.Text = ($lines -join [Environment]::NewLine)

    $tz = [TimeZoneInfo]::FindSystemTimeZoneById('Eastern Standard Time')
    $nowEt = [TimeZoneInfo]::ConvertTimeFromUtc([datetime]::UtcNow, $tz)
    $status.Text = ("Last updated {0:ddd, MMM d, yyyy h:mm:ss tt} ET · poll {1}s · {2}" -f $nowEt, ($timer.Interval/1000), $script:Source)
  } catch {
    $status.Text = "Fetch failed: $($_.Exception.Message)"
    $status.ForeColor = [System.Drawing.Color]::FromArgb(255,107,107)
  }
}

$timer.Add_Tick({ Update-Board })
$form.Add_Shown({ Update-Board; $timer.Start() })
$form.Add_FormClosed({ $timer.Stop() })
[void]$form.ShowDialog()
