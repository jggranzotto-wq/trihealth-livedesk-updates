Tri-Health Wellness Centre — Live Desk (Windows)
================================================
Read-only live board. Public price APIs only. No API keys. No trading.

SIMPLEST RUN (pick one)
-----------------------
A) Double-click  TriHealth-LiveDesk.exe
   Leaves a background host on http://127.0.0.1:47811/ and opens Edge/Chrome.
   Leave the exe running while you watch the board. Close via Task Manager when done.
   Log: livedesk.log next to the exe.

B) If the exe fails: double-click  LiveDesk.html
   OR LiveDesk.hta  (zero server — Binance direct in the browser).

C) Or Run-LiveDesk.bat

SmartScreen (unsigned exe): More info → Run anyway.

WHAT WAS WRONG (v1 → v1.1)
--------------------------
v1 killed the host when the Edge/Chrome launcher process exited. Edge often
hands off immediately, so the server died and the window showed
"refused to connect". Also opened the browser before proving the listener
was healthy, and used a random port.

v1.1 fixes:
  • Host stays alive forever (not tied to browser process lifetime)
  • Prefer fixed port 127.0.0.1:47811 (random fallback if busy)
  • Self health-check GET /api/health before launching the browser
  • All paths resolved from os.Executable() dir; livedesk.log next to exe
  • Embedded default positions if positions.json missing/invalid
  • LiveDesk.html + LiveDesk.hta zero-server fallbacks

EDIT POSITIONS / HOLDINGS
-------------------------
Exe mode: edit positions.json beside the exe (reloads ~10–15s).
  positions[] = desk signal lots (empty when flat)
  holdings[]  = wallet/cash (USD, SHIB, BONK leftover, DOGE/PEPE, VVS, ELON)
HTML/HTA mode: edit DEFAULT_CFG inside LiveDesk.html.

As of 2026-10-30 8:33 AM ET: desk open = USELESS + PUMP. Cash ~$549.26.
PEPE grid above range (likely sold to USD); DOGE grid active.
SHIB/BONK/ARB/SUI grids ended Oct 28. Prior desk lots stopped out ~21:45 ET Oct 29.
BTC Wealthsimple stop tracked at 113,000 CAD. MOG omitted.

FILES
-----
  TriHealth-LiveDesk.exe          Main host (GUI, no console)
  TriHealth-LiveDesk-console.exe  Same + console; supports -serve -port
  positions.json                  Holdings / stops / grids
  livedesk.log                    Created on first run
  LiveDesk.html                   No-server board (double-click)
  LiveDesk.hta                    Launches LiveDesk.html in Edge/Chrome
  TriHealth-LiveDesk.ps1          WinForms fallback (no install)
  Run-LiveDesk.bat                Launcher
  static/index.html / main.go     Sources

CONSOLE
-------
  TriHealth-LiveDesk-console.exe -serve
  TriHealth-LiveDesk-console.exe -port 47811


AUTO-UPDATE (v1.2+)
----------------------
The exe checks https://trihealth-livedesk-updates.onrender.com/version.json
at startup and every 10 minutes. When a newer version is listed it downloads
the new exe, verifies SHA-256, renames the running exe to .old, puts the new
one in place, relaunches, and deletes .old on the next start. No redownload.

positions.json is also pulled from that host about every 30 seconds so desk
lots and grids refresh without a new build.

To publish a new build from the agent box:
  /workspace/windows-live-desk/publish.sh
  PUBLISH_BUMP=1 /workspace/windows-live-desk/publish.sh   # bump patch

MOG is omitted from the board on purpose.
